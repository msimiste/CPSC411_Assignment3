



CPSC411 Assignment3 W-2016
Mike Simister-10095107


1. In order to pretty print you must make suer that pretty-show is installed. The command is listed below:

	cabal install pretty-show
	
2. To compile, use: 
	
	make all

3. To run all tests from Dr. Cockett's directory /home/411/M+/M+tests use:
	
	make run

4. To run individual tests after compiling with "make all":

	./Mainfile <testfile>
